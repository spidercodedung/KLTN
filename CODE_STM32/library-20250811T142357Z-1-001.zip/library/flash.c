#include "flash.h"
#include "stm32f1xx.h"
void flashErase(uint32_t address)
{
	uint32_t pageError;
	
	FLASH_EraseInitTypeDef eraseInitStruct;
	eraseInitStruct.Banks = 1;
	eraseInitStruct.NbPages = 1;
	eraseInitStruct.PageAddress = address;
	eraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	
	HAL_FLASH_Unlock();
	HAL_FLASHEx_Erase(&eraseInitStruct,&pageError);
	HAL_FLASH_Lock();
	
}
void flashWriteInt(uint32_t address, int value)
{
	HAL_FLASH_Unlock();
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address, value);
	HAL_FLASH_Lock();
}
void flashWriteFloat(uint32_t address, float value)
{
	uint8_t data[4];
	*(float *)data = value;
	HAL_FLASH_Unlock();
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, *(uint32_t *)data);
	HAL_FLASH_Lock();
}

void flashWriteArray(uint32_t address, uint8_t *array, uint16_t len)
{
	uint16_t i;
	uint16_t *pt = (uint16_t *)array;
	HAL_FLASH_Unlock();
	for(i = 0; i < (len + 1)/2; i++)
	{
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,address + 2*i, *pt);
		pt++;
	}
	HAL_FLASH_Lock();
}

int flashReadInt(uint32_t address)
{
	return *(__IO uint16_t *)(address);
}

float flashReadFloat(uint32_t address)
{
	uint32_t data = *(__IO uint32_t *)(address);
	return *(float *)(&data);
}
void flashReadArray(uint32_t address, uint8_t *array, uint16_t len)
{
	uint16_t i;
	uint16_t *pt = (uint16_t *)array;
	for(i=0; i<(len+1)/2; i++)
	{
		*pt = *(__IO uint16_t *)(address+2*i);
		pt++;
	}
}