#ifndef __FLASH_H
#define __FLASH_H
#include <stdint.h>


void flashErase(uint32_t address);
void flashWriteInt(uint32_t address, int value);
void flashWriteFloat(uint32_t address, float value);
void flashWriteArray(uint32_t address, uint8_t *array, uint16_t len);

int flashReadInt(uint32_t address);
float flashReadFloat(uint32_t address);
void flashReadArray(uint32_t address, uint8_t *array, uint16_t len);

#endif
